export default {
//   baseUrl: 'http://joyup.sr0.ru:3000/',
  /*baseUrl: 'http://localhost:3000/',*/

  /*baseUrl: '192.168.110.192:3000/',*/

  // 'https://api.mlab.com/api/1/databases/heroku_ckbhgr9b_gcloud/collections/Locations?apiKey=3y90xXI0v6E8yx8t0I6VfZi2fXKERtdX&q={"merchant_uid":xxxxx,location_id:xxxxxxx
  

baseURL: 'https://api.mlab.com/api/1/databases/waitstaff/collections/',
// apiKey : "3y90xXI0v6E8yx8t0I6VfZi2fXKERtdX",
apiKey : "3y90xXI0v6E8yx8t0I6VfZi2fXKERtdX",

merchantId: '5af4d2e2fdf525001a7d535d',
locationId: 'VAHSVKQ090R2K',

  // merchantId: '5a7371c9a67ad0001a1023f8',
  // locationId: '36XR5VCKR6AXJ',
  // 5a70fcfab4cd49001afd2e63
}
