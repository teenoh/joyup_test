export default {
    fontFamily: 'Rubik, sans-serif',
    palette: {
    },
};