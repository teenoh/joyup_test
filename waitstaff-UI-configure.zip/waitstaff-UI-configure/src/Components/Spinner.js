/**
 * Created by Yury-PC on 02.03.2018.
 */
import React, {Component} from 'react';
import CircularProgress from 'material-ui/CircularProgress';


export default class Spinner extends Component {
  render () {
    return (
      <CircularProgress />
    )
  }
}